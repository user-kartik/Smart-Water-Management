import React from "react";
import SmartWaterManagementSystem from'./components/SmartWaterManagementSystem';


function App(){
  return(
    <>
    <SmartWaterManagementSystem/>
    </>
  )

}
export default App;